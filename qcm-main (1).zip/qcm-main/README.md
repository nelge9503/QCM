# qcm
QCM en PHP
Objectif : créer une base de données avec des questions et réponses données au préalable et faire un qcm avec l’affichage des notes à la fin.
Framework utiliser : Bootstrap
,Langage utiliser : PHP
